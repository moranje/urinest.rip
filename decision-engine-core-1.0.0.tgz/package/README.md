# Decision Engine Core

<div align="center">

![Decision Engine Core](https://img.shields.io/badge/Decision%20Engine-Core-0061a4?style=for-the-badge)
[![Version](https://img.shields.io/npm/v/decision-engine-core?style=flat-square&color=0061a4)](https://www.npmjs.com/package/decision-engine-core)
[![License](https://img.shields.io/npm/l/decision-engine-core?style=flat-square&color=0061a4)](LICENSE)

**A powerful, schema-driven decision engine for building complex flow-based applications.**

</div>

---

## 📖 Overview

**Decision Engine Core** provides the foundational tools to build, validate, and execute logic-driven questionnaires and decision flows. It separates content (YAML) from logic (JavaScript), allowing you to define complex medical protocols, troubleshooting guides, or wizard-style forms with ease.

Key features:
- **YAML-based Flow Definitions**: Define questions, steps, and logic in readable YAML files.
- **Vite Plugin**: Automatically compiles and validates flows during development.
- **Runtime Engine**: Efficiently evaluate conditions and determine outcomes in your application.
- **Type-Safe**: Built with TypeScript support in mind.

---

## 📦 Installation

```bash
npm install decision-engine-core
```

---

## 🛠️ Vite Plugin

The Vite plugin watches your YAML flow definitions and compiles them into a single optimized JSON file for your application to consume.

### Setup

Add the plugin to your `vite.config.js`:

```javascript
import { defineConfig } from 'vite'
import decisionEngine from 'decision-engine-core/vite'

export default defineConfig({
  plugins: [
    decisionEngine({
      flowsDir: 'flows',       // Directory containing .yaml flow files (default: 'flows')
      outputFile: 'public/main.json' // Output path for the compiled JSON (default: 'public/main.json')
    })
  ]
})
```

Now, whenever you edit a `.yaml` file in your `flows` directory, the engine will rebuild the JSON output and trigger a hot reload.

### Output Format

The plugin generates a JSON file with the following structure:

```json
{
  "version": "1.0.0",
  "questionnaires": [
    {
      "id": "my-flow-id",
      "version": "1.0.0",
      "title": "My Decision Flow",
      "questions": [ ... ],
      "steps": [ ... ],
      "results": { ... },
      "resultsLogic": [ ... ]
    }
  ]
}
```

This JSON file contains everything your application needs to render the questionnaire and execute logic, without needing to parse YAML or process raw files at runtime.

---

## 🚀 Usage in Application

### 1. Fetch the Data

Load the generated JSON file in your application (e.g., in a Pinia store or React context).

```javascript
// Example: Fetching the data
const response = await fetch('/main.json');
const data = await response.json();

const myFlow = data.questionnaires.find(q => q.id === 'my-flow-id');
```

### 2. Render the UI

Use the `questions` and `steps` arrays to render your form.

```javascript
// Example: Rendering a step
const currentStep = myFlow.steps[0];
const stepQuestions = currentStep.questionIds.map(id =>
  myFlow.questions.find(q => q.id === id)
);
```

### 3. Execute Logic

Use the runtime API to validate answers and determine results.

```javascript
import { determineOutcome } from 'decision-engine-core';

// ... collect user answers ...

const result = determineOutcome(userAnswers, myFlow.resultsLogic);
```

---

## 📝 Defining Flows

Flows are defined in YAML files. Each file represents a self-contained decision tree or questionnaire.

### Structure

```yaml
id: my-flow-id
version: '1.0.0'
title: My Decision Flow
description: A description of what this flow does.

questions:
  age:
    type: number
    text: What is your age?
  symptoms:
    type: multiselect
    text: Select your symptoms
    options:
      - value: fever
        text: Fever
      - value: cough
        text: Cough

steps:
  - title: Basic Info
    description: Let's get to know you.
    questions: [age]
  - title: Symptoms
    description: Tell us how you feel.
    questions: [symptoms]

results:
  healthy:
    title: You are healthy!
    description: No actions needed.
  see_doctor:
    title: Consult a Doctor
    description: You should see a professional.
    contraindications:
      - text: High fever detected

logic:
  - when:
      - "age > 65"
      - "symptoms includes 'fever'"
    show: see_doctor

  - when: [] # Default fallback
    show: healthy
```

### Logic Syntax

Conditions in the `when` block use a simple, readable syntax:

| Operator | Syntax | Example |
| :--- | :--- | :--- |
| **Equals** | `==` | `status == 'active'` |
| **Not Equals** | `!=` | `role != 'admin'` |
| **Includes** | `includes` | `tags includes 'urgent'` |
| **Not Includes** | `not_includes` | `colors not_includes 'red'` |
| **In** | `in` | `category in ['A', 'B']` |
| **Not In** | `not_in` | `id not_in [1, 2, 3]` |

---

## 🧠 Runtime API

Use the core engine to evaluate user answers against your logic rules at runtime.

### `determineOutcome(answers, resultsLogic)`

Evaluates all logic rules and returns the best matching outcome.

```javascript
import { determineOutcome } from 'decision-engine-core'

const answers = {
  age: 70,
  symptoms: ['fever', 'cough']
}

// resultsLogic comes from the compiled JSON output
const result = determineOutcome(answers, flow.resultsLogic)

if (result.outcome) {
  console.log('Outcome:', result.outcome) // e.g., "result:see_doctor"
}
```

### `validateConditions(answers, conditionList)`

Checks if a specific set of conditions is met. Useful for showing/hiding individual fields or steps.

```javascript
import { validateConditions } from 'decision-engine-core'

const conditions = [
  { questionId: 'q1', operator: 'equals', value: 'yes' }
]

const { isValid } = validateConditions(answers, conditions)

if (isValid) {
  // Show the conditional field
}
```

---

## 💻 Development

If you want to contribute or modify the core engine:

```bash
# Install dependencies
npm install

# Run tests
npm test

# Build the package
npm run build
```

---

<div align="center">
  <sub>Built with ❤️ for better decision making.</sub>
</div>
